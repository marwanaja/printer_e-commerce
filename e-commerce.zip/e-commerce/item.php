<?php
class Item{
	var $IdPrinter;
	var $NamaPrinter;
	var $SpesifikasiPrinter;
	var $HargaPrinter;
	var $Jumlah;
	var $stok;
	var $image;
}
?>