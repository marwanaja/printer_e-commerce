<?php

session_start(); //Sesi

include("../koneksi.php"); //Koneksi

$id_user = $_SESSION['id_user']; //Mengambil id_user

$cart = unserialize(serialize($_SESSION['cart']));

foreach($_SESSION["cart"] as $cart => $val) {
    $subtotal = $val['HargaPrinter']*$val['Jumlah']; ?>
    <?php
    $total+=$subtotal;
}

$status = 1;
$Jumlah = 1;

//Mengupload data atau insert ke dalam tabel transaksi
$sql = "INSERT INTO transaksi (Jumlah, UserIdUser, status, Printer_tbIdPrinter, UserIdUser2) VALUES ('$total', '$id_user', '$status', '$cart' , '$id_user')";
$query = mysqli_query($koneksi, $sql);

unset($_SESSION['cart']); //Unset sesi cart
header('Location: ../cart.php'); //Dialokasikan ke halaman cart.php

?>