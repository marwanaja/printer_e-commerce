<?php

session_start(); //Sesi

include_once("../koneksi.php"); //Koneksi

$id = $_GET["id"]; //Mengambil id

$sql = "SELECT * FROM printer_tb WHERE IdPrinter =".$id; //Mengambil data dari tabel printer_tb berdasarkan IdPrinter
$query = mysqli_query($koneksi, $sql);
$printer = mysqli_fetch_object($query);

$_SESSION["cart"][$id] = [
    "NamaPrinter" => $printer->NamaPrinter,
    "SpesifikasiPrinter" => $printer->SpesifikasiPrinter,
    "HargaPrinter" => $printer->HargaPrinter,
    "Jumlah" => 1
];

header("location:../cart.php"); //Dialokasikan ke halaman cart.php

?>