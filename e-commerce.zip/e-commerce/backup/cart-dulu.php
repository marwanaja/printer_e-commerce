<?php

session_start(); //Sesi

include_once('koneksi.php'); //Koneksi

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart</title>
    <link rel="stylesheet" href="css/cart.css">

    <!-- Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">

</head>
<body>

    <!-- Navigasi -->
    <header>
        <ul>
            <li><img src="img/login.svg" width="40px" alt="Logo"></li>
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php#product">Product</a></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href="#contact">Contact</a></li>
        </ul>
        <ul>
            <!-- Cek Session, jika admin maka akan tampil link dashboard -->
            <?php
                if (isset($_SESSION['Username'])) {
                    if ($_SESSION['Username'] == 'admin') {
                        echo '
                            <li class="nav-item">
                                <a href="admin/admin.php" class="nav-link">Dashboard</a>
                            </li>
                        ';
                    } else {
                        echo '
                            <li class="nav-item">
                                <a href="admin/logout.php" class="nav-link">Logout</a>
                            </li>
                        ';
                    }
                } else {
                    echo '
                            <li class="nav-item">
                                <a href="login.php" class="nav-link">Login</a>
                            </li>
                        ';
                }
            ?>
            <li><a href="cart.php"><i class="fas fa-shopping-cart"></i></a></li>
        </ul>
    </header>

    <div class="container">
    <!-- Cek Session, jika sebagai admin, Maka script akan dimatikan dan muncul sebuah pesan "Anda bukan User" -->
    <?php

    if (isset($_SESSION["Username"])) {
        
        if ($_SESSION["Username"] == "") {
            
        } else if ($_SESSION["Username"] == "admin") {  
            die("Anda bukan User");
        }
    }
    
    if($_SESSION['status']!="login"){
        header("location:login.php?pesan=Silahkan-Login-Terlebih-Dahulu"); //Cek Session, jika blm login akan diarahkan ke login.php
    }
    
    if(!empty($_SESSION["cart"])) {
        ?>
            <table border="1" cellpadding="3">
                <tr>
                    <th> No </th>
                    <th> Nama Barang </th>
                    <th> Spesifikasi </th>
                    <th> Harga </th>
                    <th> Jumlah </th>
                    <th> Total </th>
                    <th> Opsi </th>
                </tr>
                <?php
                $no= 1;
                $total = 0;

                $cart = unserialize(serialize($_SESSION['cart']));

                //Perulangan cart
                foreach($_SESSION["cart"] as $cart => $val) {
                    $subtotal = $val['HargaPrinter']*$val['Jumlah'];
                    ?>
                    <tr>
                        <td><?php echo $no++; ?>.</td>
                        <td><?php echo $val['NamaPrinter']; ?></td>
                        <td><?php echo $val['SpesifikasiPrinter']; ?></td>
                        <td>Rp. <?php echo $val['HargaPrinter']; ?></td>
                        <td><?php echo $val['Jumlah']; ?></td>
                        <td><?php echo $subtotal; ?></td>
                        <td>
                            <a href="proses/hapus_cart.php?id=<?php echo $cart; ?>">Batal</a>
                        </td>
                    </tr>
                    <?php
                    $total+=$subtotal;
                }
            ?>
            <tr>
                <th colspan="5">Grand Total</th>
                <th><?php echo $total; ?></th>
                <!-- <th></th> -->
            </tr>
            </table>

            <a id="beli" href="proses/tambah_transaksi.php">Checkout</a>
        <?php
    } else {
        echo "<h2 style='font-weight: 600; text-align: center;'>Belum ada produk di shopping cart!</h2>";
    }
    
    ?>
    
    </div>

    <!-- Footer -->
    <div class="container footer" id="contact">
        <p>&copy; Copyright 2022 - Adityawarman Dewa Putra&nbsp;&nbsp; | &nbsp;&nbsp;Contact: dewagaming123.sp@gmail.com</p>
    </div>

</body>
</html>