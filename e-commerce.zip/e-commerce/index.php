<?php

session_start();

include_once("koneksi.php");

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>E-Commerce</title>
    <link rel="stylesheet" href="css/style.css" type="text/css">

    <!-- Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap"
        rel="stylesheet">

    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://pro.fontawesome.com/releases/v5.10.0/css/all.css"
        integrity="sha384-AYmEC3Yw5cVb3ZcuHtOA93w35dYTsvhLPVnYs9eStHfGJvOvKxVfELGroGkvsg+p" crossorigin="anonymous" />

</head>

<body>

    <!-- Navigasi -->
    <header id="desktop">
        <ul>
            <li><img src="img/Epson_logo.svg" width="80px" alt="Logo"></li>
        </ul>
        <ul>

            <li><a href="">Home</a></li>
            <li><a href="#product" class="products">Product</a></li>
            <li><a href="orders.php">Orders</a></li>
            <li><a href=" #contact">Contact</a></li>
        </ul>
        <ul>
            <!-- Cek Session, jika admin maka akan tampil link dashboard -->
            <?php

                if (isset($_SESSION['Username'])) {
                    if ($_SESSION['Username'] == 'admin') {
                        echo '
                            <li class="nav-item">
                                <a href="admin/admin.php" class="nav-link">Dashboard</a>
                            </li>
                        ';
                    } else {
                        echo '
                            <li class="nav-item">
                                <a href="admin/logout.php" class="nav-link btn">Logout</a>
                            </li>
                        ';
                    }
                } else {
                    echo '
                            <li class="nav-item">
                                <a href="login.php" class="nav-link btn">Sign in</a>
                            </li>
                        ';
                }
            ?>
            <!-- <li><a href="login.php">Login</a></li> -->
            <li><a href="cart.php"><i class="fas fa-shopping-cart"></i></a></li>
        </ul>
        <!-- <ul>
            <li><a href="login.php">Login</a></li>
            <li><a href="cart.php"><i class="fas fa-shopping-cart"></i></a></li>
        </ul> -->

    </header>


    <!-- Hero -->
    <div class="hero">
        <img src="img/printer.svg">
        <div class="wrapper">
        <h1>Welcome!</h1>
        <p>Expect great efficiency when printing with the EcoTank L121. Enjoy fast print performance
 and low cost per page, with high print yield of up to 4,500 
pages for black-and-white, and 7,500 pages for colour.
<br><br>Sleek and compact, this is the perfect fit for offices with limited space. Experience quality printing that is priced reasonably. Get this ideal printing solution for your home office today.</p>
        <a href="#product" class="btn-product">Lihat Produk</a>
        </div>
    </div>

    <!-- Post -->
    <div class="container" id="product">
        <h2>Product</h2>
        <section>
            <!-- Perulangan untuk menampilkan data product dari database -->
            <?php

            $query = "SELECT * FROM printer_tb ORDER BY IdPrinter DESC";
            $result = mysqli_query($koneksi, $query);

            while ($printer = mysqli_fetch_array($result)) { ?>
            <div class='card'>
                <div class="box">
                    <img src='img/post/<?= $printer['image']; ?>' alt='Produk' style="width: 195px;">
                </div>
                <!-- <img src='img/post/ram.svg' alt='Produk' style='width: 200px'> -->
                <div class='body-card'>
                    <h4><?= $printer['NamaPrinter']; ?></h4>
                    <p><?= $printer['SpesifikasiPrinter']; ?></p>
                    <p>Stok: <?= $printer['stok']; ?></p>
                    <p>Rp. <?= $printer['HargaPrinter']; ?></p>
                    <a href="cart.php?id=<?= $printer['IdPrinter']; ?>"><button><i
                                class="fas fa-shopping-cart"></i></button></a>
                </div>
            </div>
            <?php } ?>
        </section>
    </div>

</body>

</html>