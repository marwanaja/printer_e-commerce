<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Printer</title>
    
    <link rel="stylesheet" href="../css/tambah-edit.css" type="text/css">

    <!-- Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap" rel="stylesheet">
</head>
<body>

    <!-- Navigasi -->
    <header>
        <ul>
            <li><img src="../img/login.svg" width="40px" alt="Logo"></li>
            <li><a href="../index.php">Home</a></li>
            <li><a href="admin.php">Dashboard</a></li>
            <li><a href="history.php">History Transaksi</a></li>
        </ul>
        <ul>
        <!-- Cek Session, jika admin maka akan tampil link logout -->
        <?php
            session_start();
            if (isset($_SESSION['Username'])) {
                if ($_SESSION['Username'] == 'admin') {
                    echo '
                        <li class="nav-item">
                            <a href="logout.php" class="nav-link">Logout</a>
                        </li>
                    ';
                }
            } else {
                echo '
                        <li class="nav-item">
                            <a href="login.php" class="nav-link">Login</a>
                        </li>
                    ';
            }
        ?>
        </ul>
    </header>
    
    <section>

    <?php 

        include_once("../koneksi.php"); //Koneksi

        if($_SESSION['status']!="login"){ //Cek Sesi
            header("location:../index.php?pesan=Silahkan-Login-Terlebih-Dahulu");
        }

        if($_SESSION['Username']!="admin"){ //Cek Sesi
            die("Anda bukan Admin");
        }

    ?>

    <h2>Tambah Printer</h2>
 
    <form action="tambah.php" method="post" name="form1" enctype="multipart/form-data">
        <p>Preview:</p>
        <img id="thumb" src="<?php echo "image/".$d['image']; ?>" width="100" height="100" />
        <p><input type="file" id="image" name="berkas" value="<?php echo $d['image']; ?>" onchange="preview()"></p>
        <script>
            function preview() {
            thumb.src=URL.createObjectURL(event.target.files[0]);
            }
        </script>

        <p>Nama Barang</p>
        <p><input type="text" name="NamaPrinter"></p>
         
        <p>Spesifikasi</p>
        <p><input type="text" name="SpesifikasiPrinter"></p>
          
        <p>Harga</p>
        <p><input type="text" name="HargaPrinter"></p>
          
        <p>Stok</p>
        <p><input type="number" name="stok"></p>
         
        <p></p>
        <td><input type="submit" name="Submit" id="submit" value="Add"></p>
    </form>
    
    <?php

    if(isset($_POST['Submit'])) {
        $NamaPrinter = $_POST['NamaPrinter']; //Nama
        $SpesifikasiPrinter = $_POST['SpesifikasiPrinter']; //Spek
        $HargaPrinter = $_POST['HargaPrinter']; //Harga
        $IdUser = mysqli_insert_id($koneksi); //Id User
        $stok = $_POST['stok']; //Harga

        $namaFile = $_FILES['berkas']['name'];
        $namaSementara = $_FILES['berkas']['tmp_name'];
        
        $dirUpload = "../img/post/";
        
        $terupload = move_uploaded_file($namaSementara, $dirUpload.$namaFile);
        
        include_once("../koneksi.php"); //Koneksi

        //Mengupload atau menambahkan data ke dalam tabel printer_tb
        $result = mysqli_query($koneksi, "INSERT INTO printer_tb (NamaPrinter, SpesifikasiPrinter, HargaPrinter, image, stok) VALUES('$NamaPrinter','$SpesifikasiPrinter','$HargaPrinter', '$namaFile', '$stok')");
        
        echo "Data Berhasil di tambahkan <a href='admin.php'>View Printer</a>"; //Teks
    }
    ?>
    </section>

    <!-- Footer -->
    <div class="container footer" id="contact">
        <p>&copy; Copyright 2022 - Adityawarman Dewa Putra&nbsp;&nbsp; | &nbsp;&nbsp;Contact: dewagaming123.sp@gmail.com</p>
    </div>
    
</body>
</html>