<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>

    <link rel="stylesheet" href="../css/admin.css" type="text/css">

    <!-- Poppins -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,300;0,400;0,600;0,700;1,400&display=swap"
        rel="stylesheet">
</head>

<body>

    <!-- Navigasi -->
    <header>
        <ul>
            <li><img src="../img/login.svg" width="40px" alt="Logo"></li>
            <li><a href="../index.php">Home</a></li>
            <li><a href="history.php">History Transaksi</a></li>
        </ul>
        <ul>
            <!-- Cek Session, jika admin maka akan tampil link logout -->
            <?php
            session_start();
            if (isset($_SESSION['Username'])) {
                if ($_SESSION['Username'] == 'admin') {
                    echo '
                        <li class="nav-item">
                            <a href="logout.php" class="nav-link">Logout</a>
                        </li>
                    ';
                }
            } else {
                echo '
                        <li class="nav-item">
                            <a href="login.php" class="nav-link">Login</a>
                        </li>
                    ';
            }
        ?>
        </ul>
    </header>

    <section>

        <?php 

            include_once("../koneksi.php"); //Koneksi

            $result = mysqli_query($koneksi, "SELECT * FROM printer_tb ORDER BY IdPrinter DESC"); //Mengambil data produk atau printer_tb
            $transaksi = mysqli_query($koneksi, "SELECT * FROM transaksi ORDER BY IdTransaksi ASC"); //Mengambil data transaksi

            if($_SESSION['status']!="login"){ //Cek Session
                header("location:../index.php?pesan=Silahkan-Login-Terlebih-Dahulu");
            }

            if($_SESSION['Username']!="admin"){ //Cek Session
                die("Anda bukan Admin");
            }

        ?>

        <p><b><a href="tambah.php">Tambah Printer +</a></b></p>

        <table border="1" id="printer">

            <tr>
                <th>Gambar</th>
                <th>Nama</th>
                <th>Spesifikasi</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>Opsi</th>
            </tr>
            <?php //Perulangan untuk tabel printer_tb
        while($printer = mysqli_fetch_array($result)) { ?>
            <tr>
                <td style="width: 150px;"><img src="../img/post/<?= $printer['image']; ?>" style="width: 150px;"
                        alt="gambar">
                </td>
                <td><?= $printer['NamaPrinter']; ?></td>
                <td><?= $printer['SpesifikasiPrinter']; ?></td>
                <td class="text-center"><?= $printer['HargaPrinter']; ?></td>
                <td class="text-center"><?= $printer['stok']; ?></td>
                <td class="text-center"><a id="edit" href="edit.php?IdPrinter=<?=$printer['IdPrinter']; ?>">Edit</a> |
                    <a id="delete" href="delete.php?IdPrinter=<?=$printer['IdPrinter']; ?>">Delete</a>
                </td>
            </tr>
            <?php
        }
        ?>
        </table> <br>

        <p><b>Pesanan - Transaksi</b></p>
        <table width=' 80%' border=1>

            <tr>
                <th>No</th>
                <th>Jumlah</th>
                <th>Status</th>
                <th>Opsi</th>
            </tr>
            <?php //Perulangan untuk tabel transaksi
        while($hasil = mysqli_fetch_object($transaksi)) { if ($hasil->status == 1) { ?>
            <tr>
                <td><?= $hasil->IdTransaksi ?></td>
                <td><?= $hasil->Jumlah ?></td>
                <td class="text-center red"><a href="admin.php?id=<?= $hasil->IdTransaksi ?>">Belum Konfirmasia</a></td>
                <td class="text-center"><a href="admin.php?id=<?= $hasil->IdTransaksi ?>">Konfirmasi</a></td>
            </tr>
            <!-- <td><a href='edit.php?IdPrinter=$barang[IdPrinter]'>Edit</a> | <a href='delete.php?IdPrinter=$barang[IdPrinter]'>Delete</a></td></tr> -->
            <?php
        } }
        ?>
        </table>

        <?php 
    
        //Script ini untuk mengubah status konfirmasi dari orderan pembeli
        if (isset($_GET['id'])) {
            
            include '../koneksi.php'; //Koneksi

            $id = $_GET['id'];
            $status = 2;

            $query = "UPDATE transaksi SET status='$status' WHERE IdTransaksi = '$id'";
            $run = mysqli_query($koneksi, $query);

            if ($run) {
                header("location:admin.php");
            }

        }
        
        ?>

    </section>
</body>

</html>